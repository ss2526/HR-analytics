JanataHack - HR analytics Hackathon (Hosted in Analytics Vidhya)


PS : Given various features like geography, educational status, we have to predict if a individual would want to pursue a career in the field he has taken a skill development course in.

Link : https://datahack.analyticsvidhya.com/contest/janatahack-hr-analytics

Rank:15
